/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aa;

/**
 *
 * @author elouh
 */
import java.sql.*;
import java.util.*;
import javax.servlet.ServletContext;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class DataBean {

    private static String pathDB = "";
    private static String user = "sa";
    private static String password = "";
    private static String DBLocation = "WEB-INF/tradingDB";

    public static String getDBPath(ServletContext context) {
        pathDB = context.getRealPath("/") + DBLocation;
        return context.getRealPath("/") + DBLocation;
    }

    public static void initialize(ServletContext context) {
        Connection conn = getConnection(getDBPath(context));
        PreparedStatement deletePreparedStatement = null;
        PreparedStatement createPreparedStatement = null;
        PreparedStatement insertPreparedStatement = null;
        PreparedStatement selectPreparedStatement = null;
        String DeleteQuery = "DROP TABLE IF EXISTS USER";
        String Create1Query = "CREATE TABLE USER(id varchar(16), password varchar(128))";
        String Create2Query = "CREATE TABLE IF NOT EXISTS ASK(stock varchar(16), price int, userid varchar(16), currentTime varchar(32))";
        String Create3Query = "CREATE TABLE IF NOT EXISTS BID(stock varchar(16), price int, userid varchar(16), currentTime varchar(32))";
        String Create4Query = "CREATE TABLE IF NOT EXISTS MATCHEDTRANSACTION(stock varchar(16), price int, currentTime varchar(32), sellerid varchar(16), buyerid varchar(16))";

        String InsertQuery = "INSERT INTO USER" + "(id, password) values" + "(?,?)";
        String SelectQuery = "select * from USER";
        try {
            conn.setAutoCommit(false);

            deletePreparedStatement = conn.prepareStatement(DeleteQuery);
            deletePreparedStatement.executeUpdate();
            deletePreparedStatement.close();

            createPreparedStatement = conn.prepareStatement(Create1Query);
            createPreparedStatement.executeUpdate();
            createPreparedStatement = conn.prepareStatement(Create2Query);
            createPreparedStatement.executeUpdate();
            createPreparedStatement = conn.prepareStatement(Create3Query);
            createPreparedStatement.executeUpdate();
            createPreparedStatement = conn.prepareStatement(Create4Query);
            createPreparedStatement.executeUpdate();
            createPreparedStatement.close();

            insertPreparedStatement = conn.prepareStatement(InsertQuery);
            insertPreparedStatement.setString(1, "trader1");
            insertPreparedStatement.setString(2, "MDExMTAwMDAgMDExMDAwMDEgMDExMTAwMTEgMDExMTAwMTEgMDExMTAxMTEgMDAxMTAwMDAgMDExMTAwMTAgMDExMDAxMDA=");
            insertPreparedStatement.executeUpdate();
            insertPreparedStatement.close();

            selectPreparedStatement = conn.prepareStatement(SelectQuery);
            ResultSet rs = selectPreparedStatement.executeQuery();
            System.out.println("H2 Database inserted through PreparedStatement");
            while (rs.next()) {
                System.out.println("Username " + rs.getString("id") + " Password " + rs.getString("password"));
            }
            selectPreparedStatement.close();

            conn.commit();
            conn.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean authenticateUser(ServletContext context, String query) {
        Connection conn = getConnection(getDBPath(context));
        System.out.println("Location of db file is " + getDBPath(context));

        PreparedStatement selectPreparedStatement = null;
        boolean userFound = false;
        try {
            selectPreparedStatement = conn.prepareStatement(query);
            ResultSet rs = selectPreparedStatement.executeQuery();
            if (rs.next()) {
                userFound = true;
            }
            selectPreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return userFound;
    }

    public static Connection getConnection(String path) {
        try {
            Class.forName("org.h2.Driver");
            //Connection conn = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");                
            Connection conn = DriverManager.getConnection("jdbc:h2:" + path, user, password);
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertFromJAVADateToString(
            java.util.Date javaDate) {
        if (javaDate != null) {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");

            //to convert Date to String, use format method of SimpleDateFormat class.
            return dateFormat.format(javaDate);
        }
        return "";
    }

    public static java.util.Date convertFromStringToJAVADate(String strDate) {
        try {
            return new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").parse(strDate);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void bidAdd(Bid bid) {
        Connection conn = getConnection(pathDB);
        PreparedStatement insertPreparedStatement = null;

        try {
            String InsertQuery = "INSERT INTO BID" + "(stock, price, userid, currentTime) values ('" + bid.getStock() + "'," + bid.getPrice() + ",'" + bid.getUserId() + "','" + convertFromJAVADateToString(bid.getDate()) + "')";

            insertPreparedStatement = conn.prepareStatement(InsertQuery);
            insertPreparedStatement.executeUpdate();
            //System.out.println("The add bid statement is " + insertPreparedStatement);
            //System.out.println("The add bid result count is " + insertPreparedStatement.getUpdateCount());

            insertPreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void bidRemove(Bid bid) {
        Connection conn = getConnection(pathDB);
        PreparedStatement deletePreparedStatement = null;

        try {
            String deleteQuery = "DELETE FROM BID WHERE stock = '" + bid.getStock() + "' and price = " + bid.getPrice() + " and userid = '" + bid.getUserId() + "' and currentTime = '" + convertFromJAVADateToString(bid.getDate()) + "' LIMIT 1";
            deletePreparedStatement = conn.prepareStatement(deleteQuery);
            deletePreparedStatement.executeUpdate();
            //System.out.println("The delete bid statement is " + deletePreparedStatement);
            //System.out.println("The delete bid result count is " + deletePreparedStatement.getUpdateCount());
            deletePreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static ArrayList<Bid> getBids() {
        Connection conn = getConnection(pathDB);
        PreparedStatement selectPreparedStatement = null;
        String query = "Select * from bid";
        ArrayList<Bid> bids = new ArrayList<Bid>();
        try {
            selectPreparedStatement = conn.prepareStatement(query);
            ResultSet rs = selectPreparedStatement.executeQuery();
            while (rs.next()) {
                Bid bid = new Bid(rs.getString("stock"), rs.getInt("price"), rs.getString("userid"), convertFromStringToJAVADate(rs.getString("currenttime")));
                bids.add(bid);
            }
            selectPreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return bids;
    }

    public static void askAdd(Ask ask) {
        Connection conn = getConnection(pathDB);
        PreparedStatement insertPreparedStatement = null;

        try {
            String InsertQuery = "INSERT INTO ASK" + "(stock, price, userid, currentTime) values ('" + ask.getStock() + "'," + ask.getPrice() + ",'" + ask.getUserId() + "','" + convertFromJAVADateToString(ask.getDate()) + "')";
            insertPreparedStatement = conn.prepareStatement(InsertQuery);
            insertPreparedStatement.executeUpdate();
            //System.out.println("The add ask statement is " + insertPreparedStatement);
            //System.out.println("The add ask result count is " + insertPreparedStatement.getUpdateCount());

            insertPreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Ask getLowestAsk(String stock) {
        Connection conn = getConnection(pathDB);
        PreparedStatement selectPreparedStatement = null;
        String query = "SELECT * FROM ASK where stock = '" + stock + "' order by price asc, currenttime asc";
        Ask lowestAsk = null;
        try {
            selectPreparedStatement = conn.prepareStatement(query);
            ResultSet rs = selectPreparedStatement.executeQuery();
            if (rs.next()) {
                lowestAsk = new Ask(rs.getString("stock"), rs.getInt("price"), rs.getString("userid"), convertFromStringToJAVADate(rs.getString(("currenttime"))));
            }
            selectPreparedStatement.close();

            return lowestAsk;
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
            return lowestAsk;
        } catch (Exception e) {
            e.printStackTrace();
            return lowestAsk;
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Bid getHighestBid(String stock) {
        Connection conn = getConnection(pathDB);
        PreparedStatement selectPreparedStatement = null;
        String query = "SELECT * FROM BID where stock = '" + stock + "' order by price desc, currenttime asc";
        Bid highestBid = null;
        try {
            selectPreparedStatement = conn.prepareStatement(query);
            ResultSet rs = selectPreparedStatement.executeQuery();
            if (rs.next()) {
                highestBid = new Bid(rs.getString("stock"), rs.getInt("price"), rs.getString("userid"), convertFromStringToJAVADate(rs.getString(("currenttime"))));
            }
            selectPreparedStatement.close();

            return highestBid;
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
            return highestBid;
        } catch (Exception e) {
            e.printStackTrace();
            return highestBid;
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void askRemove(Ask ask) {
        Connection conn = getConnection(pathDB);
        PreparedStatement deletePreparedStatement = null;

        try {
            String deleteQuery = "DELETE FROM ASK WHERE stock = '" + ask.getStock() + "' and price = " + ask.getPrice() + " and userid = '" + ask.getUserId() + "' and currentTime = '" + convertFromJAVADateToString(ask.getDate()) + "' LIMIT 1";
            deletePreparedStatement = conn.prepareStatement(deleteQuery);
            deletePreparedStatement.executeUpdate();
            //System.out.println("The delete ask statement is " + deletePreparedStatement);
            //System.out.println("The delete ask result count is " + deletePreparedStatement.getUpdateCount());

            deletePreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static ArrayList<Ask> getAsks() {
        Connection conn = getConnection(pathDB);
        PreparedStatement selectPreparedStatement = null;
        String query = "Select * from ask";
        ArrayList<Ask> asks = new ArrayList<Ask>();
        try {
            selectPreparedStatement = conn.prepareStatement(query);
            ResultSet rs = selectPreparedStatement.executeQuery();
            while (rs.next()) {
                Ask ask = new Ask(rs.getString("stock"), rs.getInt("price"), rs.getString("userid"), convertFromStringToJAVADate(rs.getString("currenttime")));
                asks.add(ask);
            }
            selectPreparedStatement.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return asks;
    }

    public static void matchAdd(MatchedTransaction match) {
        Connection conn = getConnection(pathDB);
        PreparedStatement insertPreparedStatement = null;

        try {
            String InsertQuery = "INSERT INTO MATCHEDTRANSACTION" + "(stock, price, currentTime, sellerid, buyerid) values ('" + match.getStock() + "'," + match.getPrice() + ",'" + convertFromJAVADateToString(match.getDate()) + "','" + match.getSellerId() + "','" + match.getBuyerId() + "')";
            insertPreparedStatement = conn.prepareStatement(InsertQuery);
            insertPreparedStatement.executeUpdate();
            //System.out.println("The add matchedtransaction statement is " + insertPreparedStatement);
            //System.out.println("The add matchedtransaction result count is " + insertPreparedStatement.getUpdateCount());

            insertPreparedStatement.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static ArrayList<MatchedTransaction> getMatched() {
        Connection conn = getConnection(pathDB);
        PreparedStatement selectPreparedStatement = null;
        String query = "Select * from matchedtransaction";
        ArrayList<MatchedTransaction> matches = new ArrayList<MatchedTransaction>();
        try {
            selectPreparedStatement = conn.prepareStatement(query);
            ResultSet rs = selectPreparedStatement.executeQuery();
            while (rs.next()) {
                MatchedTransaction matched = new MatchedTransaction(rs.getString("stock"), rs.getInt("price"), convertFromStringToJAVADate(rs.getString("currenttime")), rs.getString("sellerid"), rs.getString("buyerid"));
                matches.add(matched);
            }
            selectPreparedStatement.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return matches;
    }
}
