package aa;

import java.util.Date;

// represents a matched bid and ask
public class MatchedTransaction {

    private Bid bid;
    private Ask ask;
    private String stock;
    private int price;
    private Date date;
    private String sellerid;
    private String buyerid;

    // constructor
    public MatchedTransaction(Bid b, Ask a, Date d, int p) {
        this.stock = b.getStock(); // or a.getStock(). will be the same
        this.price = p;
        this.date = d;
        this.ask = a;
        this.sellerid = a.getUserId();
        this.bid = b;
        this.buyerid = b.getUserId();
    }

    public MatchedTransaction(String stock, int price, Date currenttime, String sellerid, String buyerid) {
        this.stock = stock;
        this.price = price;
        this.date = currenttime;
        this.sellerid = sellerid;
        this.buyerid = buyerid;
    }

    // getter
    public String getStock() {
        return stock;
    }

    public int getPrice() {
        return price;
    }

    public Date getDate() {
        return date;
    }

    public String getBuyerId() {
        return bid.getUserId();
    }

    public String getSellerId() {
        return ask.getUserId();
    }

    // toString
    public String toString() {
        return "stock: " + stock + ", amt: " + price + ", bidder userId: " + buyerid + ", seller userId: " + sellerid + ", date: " + date;
    }
}
