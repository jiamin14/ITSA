$("#login-button").click(function (event) {
    event.preventDefault();

    $('form').fadeOut(500);
    $('.wrapper').addClass('form-success');
});

function checkForm(form) {
    var idCheck = checkId(form.elements['id']);
    return idCheck;
}
function checkId(input) {
    var check = input.value.length >= 1;
    input.style.borderColor = check ? 'black' : 'red';
    myform.id.focus();
    return check;
} 